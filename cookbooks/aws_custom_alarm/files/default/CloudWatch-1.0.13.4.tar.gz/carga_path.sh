#/bin/bash

cat /usr/share/CloudWatch/variable_path  >>/etc/bash.bashrc 
